package Code1;

import com.napier.sem.App;

/**
 * Hello Group 5
 */

public class Intro {

    public static void main(String[] args){
        System.out.println("Boo yah!");
        System.out.println("Hello Group 5 SEM");
        System.out.println("Group members: ");
        System.out.println(" ");
        System.out.println("Kaamini " + "Emillia " + "Valentin " + "Matthew " + "Rajan ");
    }
}
