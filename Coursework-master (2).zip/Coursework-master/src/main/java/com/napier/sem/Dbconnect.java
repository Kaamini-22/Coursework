package com.napier.sem;

public class Dbconnect {
}
