Software engineering method
Group 5
Team members:
Puteri Binte Samian = 40582939
Matthew George = 40598611
Kaamini Kulanthlu = 40578064
Rajan Poudel = 40542238
Valentin Rosemberg Mentasti= 40533866

Roles of team member
1.Product owner= Kaamini Kulanthlu = 40578064
2.Scrum master= Rajan Poudel = 40542238
Other members of the team are working on dockers and java during first few weeks.
All the team members meet before lab class and share what we have done and help each other. We have created a WhatsApp group to ask any question and make plans for our group project. Everyone is supposed to complete their part independently. For first few weeks we spend time on setting up GitHub repositories, IntelliJ, docker and public GitHub repositories for group.
First 3 weeks
For the first 3 weeks all the group members engage with lab session and we setup all the necessary software according to lab slides. If anyone had any issues, we discussed helped each other within lab as well as through group chats.
After we setup GitHub, IntelliJ and docker we started to work on code review.
Things to do for code review 1:
1. GitHub project for coursework set-up.
2. Product Backlog created.
3. Project builds to self-contained JAR with Maven.
4. Docker file for project set-up and works.
5. GitHub Actions for project set-up and build is working using JAR and Docker on GitHub Actions.
6. Correct branches for Git-Flow workflow created - includes master, develop, and release branches.
7. First release created on GitHub.
8. Code of Conduct defined.

Valentine was working on code of conduct. We all team members agreed to follow the rules. After our code of conduct was defined we started working on other task for code review. February 10 was review date so all the team members were on lab for the review. We showed our task to Dr Andreas Steyven. We found out we were missing many things to do. Therefore, the review did not go as we were hoping but we agreed to finish undone task before upcoming Sunday. We divide our task and started working on that.
In following days we all team members meet in university in lecture class and planned to work on second code review. We were also keeping up with lab session and doing individual part at home. If anyone had any problem they asked in groups and in lab class. Lab session were of great help. Professor were very helpful, and they provided many information and solved our many IntelliJ and GitHub issues.
 
Things to do for code review 2:
1. Issues being used on GitHub.
2. Tasks defined as user stories.
3. Project integrated with Zube.io.
4. Kanban/Project Board being used.
5. Sprint Boards being used.
6. Full use cases defined.
7. Use case diagram created.
We separated the task in group and agreed to help each other. We split the task according to our choices and discussed any  issue in WhatsApp group . The submission for code review 2 is on Friday 3 march.
On Friday 3rd March we submitted our code review 2. Overall we got good score but  work more on use case diagram, defining full use case and we have to use kanban board more often to communicate about ready, in progress and completed task so that all group members knows what to do next. From following weeks we actively started using kanban bord to do our task. 
Next we have to focus on defining integration test and unit test. This was a little bit tougher than we thought to be. All the team members gave their best for the code review 3 but we were missing most of the task that needed to be done for this code review. We all agreed to work more on the unit test and integration test. 
We group members were communicating with each other from whatsapp. We couldnot meet on easter break but actively participate for the task for next code review through social media and our group leader assigned task for each member so that everybody knew what they have to do. 
Today 28th april; final day for our code review submission. We have to show our Deployment working and Bug reporting system set-up. 

 
